# ☕ Tim Hortons India — Portal Server
### Share your Ops & Training Portal with all 44 stores

---

## 📁 Folder Structure

```
timhortons-portal/
├── server.js                    ← main server
├── timhortons_v2_final.html     ← your portal (DO NOT rename)
├── package.json
├── ecosystem.config.js          ← PM2 config
├── .env.example                 ← copy → .env to configure
├── Procfile                     ← for Railway / Render / Heroku
├── START-WINDOWS.bat            ← double-click on Windows
├── start-mac-linux.sh           ← run on Mac / Linux
└── logs/                        ← auto-created, server logs
```

---

## ✅ Prerequisites

Install **Node.js** (one-time): https://nodejs.org → choose **LTS**

Verify:
```bash
node --version   # should print v16 or higher
```

---

## 🚀 Option 1 — Run on Your Computer (Same Network)

Best if all 44 stores are on the **same office / VPN network**.

**Windows:** Double-click `START-WINDOWS.bat`

**Mac / Linux:**
```bash
chmod +x start-mac-linux.sh
./start-mac-linux.sh
```

**Or manually:**
```bash
node server.js
```

You'll see your **network URL** printed in the terminal:
```
  Network:  http://192.168.1.50:8080  ← share this with stores
```

Send that URL to all 44 store managers. They just open it in any browser.

> ⚠️ Your computer must stay ON for stores to access the portal.

---

## 🔄 Option 2 — PM2 (Always On, No Window Needed)

PM2 keeps the server running in the background — even after you close the terminal or reboot.

```bash
# Install PM2 once
npm install -g pm2

# Start the portal
pm2 start ecosystem.config.js

# Save so it auto-starts after reboot
pm2 save
pm2 startup    # then run the command it prints

# Useful commands
pm2 status                    # see if it's running
pm2 logs timhortons-portal    # view live logs
pm2 restart timhortons-portal # restart after changes
pm2 stop timhortons-portal    # stop it
```

---

## 🌐 Option 3 — Cloud Hosting (Best for Remote Stores)

If stores are in different cities and NOT on the same network, host on the internet. Free options:

### Railway (Easiest — Recommended)

1. Create account at https://railway.app
2. Push your folder to GitHub:
   ```bash
   git init
   git add .
   git commit -m "Tim Hortons portal"
   # create repo on github.com, then:
   git remote add origin https://github.com/YOUR_USER/timhortons-portal.git
   git push -u origin main
   ```
3. In Railway: **New Project → Deploy from GitHub** → select your repo
4. Railway auto-detects Node.js and deploys. You get a URL like:
   `https://timhortons-portal-xxxx.railway.app`
5. Share that URL with all 44 stores — works from anywhere!

### Render (Also Free)

1. Create account at https://render.com
2. **New → Web Service → Connect GitHub** → select your repo
3. Build command: *(leave blank)*
4. Start command: `node server.js`
5. Deploy → get your URL

### Environment Variables on Cloud

In Railway or Render, set these in the dashboard:
```
PORT=8080
HTML_FILE=timhortons_v2_final.html
```

---

## ⚙️ Configuration

Copy `.env.example` to `.env` and edit:
```bash
cp .env.example .env
```

```env
PORT=8080                          # change if 8080 is taken
HTML_FILE=timhortons_v2_final.html # portal filename
```

---

## 🔍 Useful URLs

| URL | What it does |
|-----|-------------|
| `http://YOUR_IP:8080` | The portal (share this) |
| `http://YOUR_IP:8080/health` | Server health check |

---

## 🛠️ Troubleshooting

| Problem | Fix |
|---------|-----|
| "Port already in use" | Edit `.env` → change `PORT=3000` |
| Stores can't connect | Check Windows Firewall → allow port 8080 |
| Server stops when terminal closes | Use PM2 (Option 2) |
| Page not loading | Make sure HTML file is in same folder as server.js |
| Wrong IP shown | Your router IP may have changed; run `ipconfig` (Win) or `ifconfig` (Mac/Linux) |

### Allow port through Windows Firewall:
```
Windows Firewall → Advanced Settings →
Inbound Rules → New Rule → Port → TCP → 8080 → Allow
```

### Find your IP address:
- **Windows:** Open CMD → `ipconfig` → look for `IPv4 Address`
- **Mac:** System Preferences → Network, or Terminal: `ipconfig getifaddr en0`
- **Linux:** `hostname -I` or `ip addr show`

---

## 📊 Logs

Access logs are saved to `access.log` in the same folder.
Each line:
```
[14/04/2026, 09:15:33 AM] 200 GET / — 192.168.1.22 — 48291B
```

With PM2, logs go to `logs/out.log` and `logs/error.log`.

---

## 🔐 Security Notes

- The portal has its own login system with role-based access
- Change default demo passwords from the Admin panel before sharing
- For extra security on cloud, consider adding HTTPS via a reverse proxy (nginx/Caddy)

---

*Questions? Check the `/health` endpoint first — if it returns `{"status":"ok"}` the server is running correctly.*
