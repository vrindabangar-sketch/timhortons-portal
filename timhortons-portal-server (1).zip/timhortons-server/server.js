/**
 * ☕ Tim Hortons India — Ops & Training Portal
 * Production Server
 * ─────────────────────────────────────────────
 * Features:
 *  • Serves the portal to all 44 stores
 *  • Request logging with timestamps (IST)
 *  • Graceful shutdown
 *  • Health-check endpoint
 *  • Configurable via .env or environment variables
 */

'use strict';

const http    = require('http');
const fs      = require('fs');
const path    = require('path');
const url     = require('url');
const os      = require('os');

// ── Load .env if present ────────────────────────────────
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
  fs.readFileSync(envPath, 'utf8')
    .split('\n')
    .forEach(line => {
      const [key, ...val] = line.split('=');
      if (key && key.trim() && !key.startsWith('#')) {
        process.env[key.trim()] = val.join('=').trim();
      }
    });
}

// ── Config ──────────────────────────────────────────────
const PORT      = parseInt(process.env.PORT || '8080', 10);
const HTML_FILE = path.join(__dirname, process.env.HTML_FILE || 'timhortons_v2_final.html');
const LOG_FILE  = path.join(__dirname, 'access.log');

// ── MIME map ────────────────────────────────────────────
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css' : 'text/css',
  '.js'  : 'application/javascript',
  '.json': 'application/json',
  '.png' : 'image/png',
  '.jpg' : 'image/jpeg',
  '.ico' : 'image/x-icon',
  '.svg' : 'image/svg+xml',
  '.woff2':'font/woff2',
};

// ── Logger ───────────────────────────────────────────────
const logStream = fs.createWriteStream(LOG_FILE, { flags: 'a' });

function log(req, status, bytes) {
  const now = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', hour12: true });
  const ip  = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '?').split(',')[0].trim();
  const ua  = (req.headers['user-agent'] || '').substring(0, 60);
  const line = `[${now}] ${status} ${req.method} ${req.url} — ${ip} — ${bytes || 0}B`;
  console.log(line);
  logStream.write(line + '\n');
}

// ── Get local IPs ────────────────────────────────────────
function getLocalIPs() {
  const ips = [];
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === 'IPv4' && !net.internal) ips.push(net.address);
    }
  }
  return ips;
}

// ── Server ───────────────────────────────────────────────
const server = http.createServer((req, res) => {
  const parsed   = url.parse(req.url);
  const pathname = parsed.pathname;

  // ── Health check ──
  if (pathname === '/health') {
    const body = JSON.stringify({
      status  : 'ok',
      uptime  : Math.floor(process.uptime()) + 's',
      time    : new Date().toISOString(),
      port    : PORT,
    });
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(body);
    log(req, 200, body.length);
    return;
  }

  // ── Portal (root) ──
  if (pathname === '/' || pathname === '/index.html' || pathname === '/portal') {
    fs.readFile(HTML_FILE, (err, data) => {
      if (err) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('Server Error: portal file missing. Check server setup.');
        log(req, 500, 0);
        return;
      }
      res.writeHead(200, {
        'Content-Type' : 'text/html; charset=utf-8',
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma'       : 'no-cache',
        'Expires'      : '0',
        'X-Powered-By' : 'Tim Hortons Portal',
      });
      res.end(data);
      log(req, 200, data.length);
    });
    return;
  }

  // ── Static files (images, icons, etc.) ──
  const safePath = path.join(__dirname, 'public', path.basename(pathname));
  if (pathname.startsWith('/public/') && fs.existsSync(safePath) && fs.statSync(safePath).isFile()) {
    const ext  = path.extname(safePath).toLowerCase();
    const mime = MIME[ext] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': mime, 'Cache-Control': 'max-age=86400' });
    const stream = fs.createReadStream(safePath);
    stream.pipe(res);
    log(req, 200, 0);
    return;
  }

  // ── 404 ──
  const body404 = `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Not Found</title>
<style>body{font-family:sans-serif;background:#1E0D02;color:#fff;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;flex-direction:column;gap:16px;}
a{color:#C8102E;font-weight:700;}</style></head>
<body><div style="font-size:48px">☕</div><h2>Page Not Found</h2><a href="/">← Back to Portal</a></body></html>`;
  res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(body404);
  log(req, 404, body404.length);
});

// ── Start ────────────────────────────────────────────────
server.listen(PORT, '0.0.0.0', () => {
  const ips = getLocalIPs();
  console.log('');
  console.log('  ☕  Tim Hortons India — Ops & Training Portal');
  console.log('  ═══════════════════════════════════════════════');
  console.log(`  Local:    http://localhost:${PORT}`);
  ips.forEach(ip => console.log(`  Network:  http://${ip}:${PORT}  ← share with stores`));
  console.log('');
  console.log(`  Logs:     ${LOG_FILE}`);
  console.log(`  Portal:   ${path.basename(HTML_FILE)}`);
  console.log('');
  console.log('  Press Ctrl+C to stop.');
  console.log('');
});

// ── Graceful shutdown ────────────────────────────────────
function shutdown(signal) {
  console.log(`\n  [${signal}] Shutting down gracefully...`);
  server.close(() => {
    logStream.end();
    console.log('  Server stopped. Goodbye! ☕\n');
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 5000);
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT',  () => shutdown('SIGINT'));

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\n  ✗  Port ${PORT} is in use. Try: PORT=3000 node server.js\n`);
  } else {
    console.error('\n  Server error:', err.message);
  }
  process.exit(1);
});
