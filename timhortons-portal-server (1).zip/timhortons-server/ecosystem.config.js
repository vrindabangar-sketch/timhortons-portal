/**
 * PM2 Ecosystem Config
 * ─────────────────────
 * Usage:
 *   pm2 start ecosystem.config.js
 *   pm2 save
 *   pm2 startup
 */

module.exports = {
  apps: [
    {
      name        : 'timhortons-portal',
      script      : 'server.js',
      instances   : 1,           // increase to 'max' on multi-core servers
      autorestart : true,        // restart if it crashes
      watch       : false,       // set to true to auto-reload on file changes
      max_memory_restart: '200M',

      env: {
        NODE_ENV : 'production',
        PORT     : 8080,
      },

      // Log files
      out_file    : './logs/out.log',
      error_file  : './logs/error.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss',
      merge_logs  : true,
    },
  ],
};
