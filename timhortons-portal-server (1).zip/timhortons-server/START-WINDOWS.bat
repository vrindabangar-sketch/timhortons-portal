@echo off
title Tim Hortons Portal Server
echo.
echo   Checking Node.js...
node --version >nul 2>&1
if %errorlevel% neq 0 (
  echo   ERROR: Node.js not found!
  echo   Download from: https://nodejs.org
  pause
  exit /b 1
)

echo   Starting Tim Hortons Portal...
echo   Press Ctrl+C to stop the server.
echo.
node server.js
pause
