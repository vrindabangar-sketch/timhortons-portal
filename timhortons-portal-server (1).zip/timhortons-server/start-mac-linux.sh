#!/bin/bash
echo ""
echo "  Checking Node.js..."
if ! command -v node &> /dev/null; then
  echo "  ERROR: Node.js not found!"
  echo "  Download from: https://nodejs.org"
  exit 1
fi

echo "  Starting Tim Hortons Portal..."
echo "  Press Ctrl+C to stop."
echo ""
node server.js
